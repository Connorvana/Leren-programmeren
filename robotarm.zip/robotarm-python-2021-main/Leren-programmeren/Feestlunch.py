croissants= input('hoeveel croissants?:')
print(0.39* int(croissants))

stokbrood= input('Hoeveel stokbroodjes?:')
print(2.78* int(stokbrood))

totaal= ((0.39* int(croissants)) + (2.78* int(stokbrood)-1.50))

print( ' De feestlunch kost je bij de bakker '+ str(totaal) +  ' euro voor de '+ str(croissants) + ' croissantjes en de ' + str(stokbrood) + ' stokbroden als de 3 kortingsbonnen nog geldig zijn ')








