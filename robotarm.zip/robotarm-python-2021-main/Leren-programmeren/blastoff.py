for i in range (30,-1,-1):
    print(i)
    
print('BLASTOFF!!!')
