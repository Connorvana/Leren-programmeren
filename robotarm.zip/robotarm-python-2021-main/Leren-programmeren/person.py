name= 'connor van amersfoort'
adres= 'kerkplein, 3, uitwijk'
postcode= '4288JE'
woonplaats= 'Uitwijk'
print('____________________')
print('|' + str (name)  )                         
print('|' + str (adres) )
print('|' + str (postcode))
print('|' + str (woonplaats)) 
print('|______________________')










 