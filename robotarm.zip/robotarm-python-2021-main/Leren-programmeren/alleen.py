for i in range(22,50,2):
    print(i)