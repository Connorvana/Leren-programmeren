#vraag de gebruiker om zijn/haar leeftijd
#als de gebruker ouder is dan 18 mag hij of zij naar binnen 
#anders moeten zij buiten blijven

leeftijd= input('Wat is je leeftijd?:')

if leeftijd  > '17':
    print('je mag naar binnen ')
else:
    print('je moet buiten blijven ')

if leeftijd > '21':
    print('en je krijgt een bandje mee ')

naam= input('wat is je naam?')

if naam == 'rudi': 
    print('je krijgt een sticker')
if naam == 'arnold':
    print('je krijgt een sticker')
if naam == 'jeroen':
    print('je krijgt een sticker')
if naam == 'kjeld':
    print('je krijgt een sticker')







